// 1. Write a JS code to print numbers from 1 to 10

console.log("1. Write a JS code to print numbers from 1 to 10")

function printNumbers(){
    for(var i=1;i<=10;i++)
    {
        console.log(i)
    }
}
printNumbers()

// 2. Write a JS code to print a 2D array
console.log("2. Write a JS code to print a 2D array")
function printArray(arr){
 for(var i=0;i<arr.length;i++)
 {
    for(var j=0;j<arr[i].length;j++)
    {
        console.log(arr[i][j])
    }
 }
}

var arr = [[1, 2],[3, 4],[5, 6]]
printArray(arr)


// 3. Write a JS code to print Even numbers in given array
console.log("3. Write a JS code to print Even numbers in given array")
function evennumber(arr){
    for(var i=0;i<arr.length;i++){
        if(arr[i]%2==0){
            console.log(arr[i])
        }

    }

}
var arr= [13,23,12,45,22,48,66,100];
evennumber(arr)

//4. Write a JS code to delete all occurrence of element in given array
console.log("4. Write a JS code to delete all occurrence of element in given array")
function delelement(arr,d){
    for(var i=0;i<arr.length-1;i++){
        if(arr[i]==d){
            arr.splice(i,1)
        }
        console.log(arr[i])
    }

}
var arr = [23,56,4,78,5,63,45,210,56];

delelement(arr,56)

//5. Write a JS code to find the power of a number using for loop
console.log("5. Write a JS code to find the power of a number using for loop")
function numpower(n1,n2){
    var result=1;
 for(i=0;i<n2;i++)
 {
    result*=n1
 }
 console.log(result)
}

numpower(4,3)

//6. Write a JS code to print a pattern using for loop
console.log("6. Write a JS code to print a pattern using for loop")

function printpattern(n){
   
    for(i=1;i<=n;i++)
    {
        var output=""
        for(j=1;j<=i;j++)
        {
            output+=j +" ";
        }
        console.log(output)

    }
}
printpattern(8)

//7. Write a JS code to find the largest number in an array
console.log("7. Write a JS code to find the largest number in an array")
function max(arr){
    var largest=0;
    for(var i=0;i<arr.length;i++){
        if(arr[i]>largest){
            largest=arr[i];
        }
    }
    console.log(largest)

}
var arr = [2, 45, 3, 67, 34, 567, 34, 345, 123];
max(arr)